num = int(input("Digite um número para ver a sua tabuada: "))

i = 1
while True:
    result = num * i
    print(f"{num} x {i} = {result}")
    i += 1
